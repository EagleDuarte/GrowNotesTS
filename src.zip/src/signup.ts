btnAdd.addEventListener("click", realizarCadastro);
btnCreate.addEventListener("click", validarUsuario);

function registrarUsuario() {
  const usuario = {
    email: email.value,
    senha: senha1.value,
  };

  listaDeUsuarios.push(usuario);

  salvarListaUsuariosNoCache();
}

function redirecionarUsuario() {
  window.location.href = "login.html";
}

function salvarListaUsuariosNoCache() {
  const novosUsuarios = JSON.stringify(listaDeUsuarios);

  localStorage.setItem("usuarios", novosUsuarios);

  redirecionarUsuario();
}

function validarUsuario() {
  if (!email.value || !senha1.value) {
    alert("Campos Vazios!");
    return;
  }

  if (senha1.value !== senha2.value) {
    alert("As senhas não coincidem!");
    return;
  }

  verificarUsuario();

  registrarUsuario();
}

function verificarUsuario() {
  const resultado = listaDeUsuarios.find(
    (usuario: User) => usuario.email == email.value
  );

  if (resultado) {
    alert("Usuário já existente!");
  }
}
